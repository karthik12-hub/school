import * as React from 'react';
import {View,Text,StyleSheet,TouchableOpacity} from 'react-native'
import db from './config'

export default class App extends React.Component{
  kp=()=>{
    var presentk =db.ref('karthik/'+'/')
    presentk.update({
     'Attendence':true
    })
  }
  ka=()=>{
    var presentkp =db.ref('karthik/'+'/')
    presentkp.update({
     'Attendence':false
    })
  }

    mp=()=>{
    var presentm =db.ref('mahi tr/'+'/')
    presentm.update({
     'Attendence':true
    })
  }
  ma=()=>{
    var presentma =db.ref('mahi tr/'+'/')
    presentma.update({
     'Attendence':false
    })
  }

   wp=()=>{
    var presentw =db.ref('white hat/'+'/')
    presentw.update({
     'Attendence':true
    })
  }
  su=()=>{
    var presents=db.ref('submited/'+'/')
    presents.update({
     'submit':true
    })
  }
  wa=()=>{
    var presentwa =db.ref('white hat/'+'/')
    presentwa.update({
     'Attendence':false
    })
  }
  render(){
    return(
      <View>

      <Text style={styles.textStyle}>
      SCHOOL ATTENDENCE APP
      </Text>

      <TouchableOpacity style={styles.submitStyle} onPress={(this.su)}>
       <Text style={{fontSize:20}}>
        SUBMIT
       </Text>
      </TouchableOpacity>

      <Text style={styles.kstyle}>
       1. KARTHIK
      </Text>

      <TouchableOpacity style={styles.prestyle}  onPress={(this.kp)}>
       
      present
      </TouchableOpacity>
      <TouchableOpacity style={{ backgroundColor:"red",
                                marginTop:-21,
                                 justifyContent:"center",
                                alignSelf:"center",
                                fontSize:21,
                                marginLeft:200,
                                borderRadius:20
                              }} onPress={(this.ka)}>
      absent
      </TouchableOpacity>

      <Text style={{fontSize:20,
   marginTop:70}}>
       2. MAHI TR
      </Text>

      <TouchableOpacity style={styles.prestyle} onPress={(this.mp)}>
      present
      </TouchableOpacity>

      <TouchableOpacity style={{ backgroundColor:"red",
                                marginTop:-21,
                                 justifyContent:"center",
                                alignSelf:"center",
                                fontSize:21,
                                marginLeft:200,
                                borderRadius:20
                              }} onPress={(this.ma)}>
      absent
      </TouchableOpacity>

      <Text style={{fontSize:20,
   marginTop:70}}>
       3. WHIITEHAT
      </Text>

      <TouchableOpacity style={styles.prestyle} onPress={(this.wp)}>
      present
      </TouchableOpacity>

      <TouchableOpacity style={{ backgroundColor:"red",
                                marginTop:-21,
                                 justifyContent:"center",
                                alignSelf:"center",
                                fontSize:21,
                                marginLeft:200,
                                borderRadius:20
                              }} onPress={(this.wa)}>
      absent
      </TouchableOpacity>
      </View>
    )
  }
}

var styles =StyleSheet.create({
  textStyle:{
    fontSize:27.5,
    backgroundColor:"blue",
    marginTop:20,
    justifyContent:"center",
    alignSelf:"center"
  },
  submitStyle:{
    backgroundColor:"yellow",
    marginTop:400,
    justifyContent:"center",
    alignItems:"center",
    width:200,
    alignSelf:"center",
    borderRadius:20
  },
  kstyle:{
   fontSize:20,
   marginTop:-350
   
  },
  prestyle:{
   backgroundColor:"green",
    marginTop:-20,
    justifyContent:"center",
    alignSelf:"center",
    fontSize:20,
    borderRadius:20
  }

})



