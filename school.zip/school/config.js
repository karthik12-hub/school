import firebase from 'firebase';

 var firebaseConfig = {
    apiKey: "AIzaSyBupWzopozTnTnf9Hbau-OFP0d7sFN1Usc",
    authDomain: "school-c5dd3.firebaseapp.com",
    databaseURL: "https://school-c5dd3-default-rtdb.firebaseio.com",
    projectId: "school-c5dd3",
    storageBucket: "school-c5dd3.appspot.com",
    messagingSenderId: "974345781710",
    appId: "1:974345781710:web:3191cb688de04cd0052b9f",
    measurementId: "G-E79HRKLRHZ"
  };
  if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}
 export default firebase.database();